package ahp_model;

/**
 * Created by yevvy on 26/03/2017.
 */
public class Alternative {
    int id;
    String name;
}
