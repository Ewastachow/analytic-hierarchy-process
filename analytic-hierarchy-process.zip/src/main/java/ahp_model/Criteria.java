package ahp_model;

import Jama.Matrix;

import java.util.List;

/**
 * Created by yevvy on 26/03/2017.
 */

public class Criteria {

    Matrix matrix;
    boolean hasSubcriteria;

    List<Criteria> subcriteriaList;

}
