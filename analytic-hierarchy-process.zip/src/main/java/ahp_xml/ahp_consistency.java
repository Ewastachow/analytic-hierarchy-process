package ahp_xml;

import Jama.Matrix;

/**
 * Created by yevvy on 01/04/2017.
 */
public class ahp_consistency {

    static boolean isAhpMatrixConsistency(Matrix matrix){
        //todo: Implement
        return true;
    }
}
