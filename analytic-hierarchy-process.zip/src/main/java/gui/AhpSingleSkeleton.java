package gui;

/**
 * Created by yevvy on 29/03/2017.
 */
public class AhpSingleSkeleton {
}
