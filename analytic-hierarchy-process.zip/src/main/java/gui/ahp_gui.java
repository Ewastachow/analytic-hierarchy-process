package gui;/**
 * Created by yevvy on 26/03/2017.
 */

import javafx.application.Application;
import javafx.stage.Stage;

public class ahp_gui extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {

    }
}
