package ahp_model_to_xml;

import ahp_model.AHP;

/**
 * Created by yevvy on 01/04/2017.
 */
public class AhpToXml {

    AHP ahpModel;


}
